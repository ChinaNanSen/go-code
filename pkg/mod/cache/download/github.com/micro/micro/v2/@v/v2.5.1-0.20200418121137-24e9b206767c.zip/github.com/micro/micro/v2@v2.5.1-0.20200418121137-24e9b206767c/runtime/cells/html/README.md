Micro cell for HTML sites
===

```sh
 docker build -t html .; docker run --name=html -p 8910:8080 html https://github.com/crufter/micro-cell-html-test folder

```
# Single Page Apps

This is for single page apps (SPA)

## Usage

```sh
 docker build -t hspa .; docker run --name=spa -p 8910:8080 spa https://github.com/crufter/micro-cell-html-test folder

```

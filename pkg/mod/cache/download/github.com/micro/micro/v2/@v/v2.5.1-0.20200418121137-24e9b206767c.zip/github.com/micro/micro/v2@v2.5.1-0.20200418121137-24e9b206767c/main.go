package main

import (
	"github.com/micro/micro/v2/cmd"
)

func main() {
	cmd.Init()
}

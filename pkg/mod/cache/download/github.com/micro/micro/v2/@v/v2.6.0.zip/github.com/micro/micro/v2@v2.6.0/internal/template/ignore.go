package template

var (
	GitIgnore = `
{{.Alias}}-{{.Type}}
`
)

# Platform Docs

This serves as the location for any platform documentation related to further deployment or design.

# Contents

- [architecture](architecture.md) - platform composition
- [configuration](configuration.md) - platform configuration
- [workflow](workflow.md) - the user workflow

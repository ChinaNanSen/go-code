package template

var (
	Module = `module {{.Dir}}`
)

package main

import (
	"github.com/micro/micro/cmd"
)

func main() {
	cmd.Init()
}

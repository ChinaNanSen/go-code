# uTP Transport

The uTP transport is a go-micro transport which makes use of github.com/anacrolix/utp

uTP is the [Micro Transport Protocol](https://en.wikipedia.org/wiki/Micro_Transport_Protocol) an 
open UDP variant of the BitTorrent protocol.


The uTP transport in combination with STUN allows for peer to peer communication.

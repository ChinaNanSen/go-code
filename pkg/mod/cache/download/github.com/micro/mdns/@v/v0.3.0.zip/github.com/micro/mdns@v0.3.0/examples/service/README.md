# service

Compile + run:

```
go build
./service
```

[The, run the client](../service)


Use another service tag

```
./service <service-tag>
./service _foobarbaz._tcp
```

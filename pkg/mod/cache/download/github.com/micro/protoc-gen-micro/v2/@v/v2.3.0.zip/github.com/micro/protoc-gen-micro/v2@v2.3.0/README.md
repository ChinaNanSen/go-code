# Protoc-gen-micro

Protoc-gen-micro has moved to [micro/cmd/protoc-gen-micro](https://github.com/micro/micro/tree/master/cmd/protoc-gen-micro)

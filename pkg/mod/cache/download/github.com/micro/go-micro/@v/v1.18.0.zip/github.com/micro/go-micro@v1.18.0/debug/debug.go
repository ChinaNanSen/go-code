// Package debug provides micro debug packages
package debug

var (
	// DefaultName is the name of debug service
	DefaultName = "go.micro.debug"
)

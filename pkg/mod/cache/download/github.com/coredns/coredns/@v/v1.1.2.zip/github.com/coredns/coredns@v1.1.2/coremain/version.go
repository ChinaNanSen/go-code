package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.1.2"
	coreName    = "CoreDNS"
	serverType  = "dns"
)

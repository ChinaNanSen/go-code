package proxy

// TODO(miek):
// Test cert failures - put those in SERVFAIL messages, but attach error code in TXT
// Test connecting to a a bad host.

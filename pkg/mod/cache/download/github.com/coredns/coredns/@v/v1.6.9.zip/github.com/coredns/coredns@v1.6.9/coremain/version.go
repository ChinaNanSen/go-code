package coremain

// Various CoreDNS constants.
const (
	CoreVersion = "1.6.9"
	coreName    = "CoreDNS"
	serverType  = "dns"
)

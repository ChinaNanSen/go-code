package B

import "github.com/onsi/C"

func DoIt() string {
	return C.DoIt()
}

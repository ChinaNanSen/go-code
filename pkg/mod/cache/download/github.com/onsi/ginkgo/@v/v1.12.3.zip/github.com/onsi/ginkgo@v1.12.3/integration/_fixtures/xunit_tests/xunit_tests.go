package xunit_tests

func AlwaysTrue() bool {
	return true
}

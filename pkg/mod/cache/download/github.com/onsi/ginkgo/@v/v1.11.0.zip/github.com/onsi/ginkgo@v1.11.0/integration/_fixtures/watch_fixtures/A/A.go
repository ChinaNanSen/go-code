package A

import "github.com/onsi/B"

func DoIt() string {
	return B.DoIt()
}

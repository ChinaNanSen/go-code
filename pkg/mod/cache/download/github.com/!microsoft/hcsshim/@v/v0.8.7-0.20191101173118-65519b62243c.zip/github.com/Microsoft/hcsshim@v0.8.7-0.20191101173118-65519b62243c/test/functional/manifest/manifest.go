package manifest

// This is so that tests can include the .syso to manifest them to pick up the right Windows build
// TODO: Auto-generation of the .syso through rsrc or similar.

package functional

import _ "github.com/Microsoft/hcsshim/test/functional/manifest"

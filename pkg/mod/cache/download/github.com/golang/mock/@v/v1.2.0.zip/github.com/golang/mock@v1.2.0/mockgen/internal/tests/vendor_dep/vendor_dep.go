package vendor_dep

import "a"

type VendorsDep interface {
	Foo() a.Ifc
}

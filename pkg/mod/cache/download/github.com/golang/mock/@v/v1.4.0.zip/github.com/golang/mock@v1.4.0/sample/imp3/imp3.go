package imp3

type Imp3 struct{}

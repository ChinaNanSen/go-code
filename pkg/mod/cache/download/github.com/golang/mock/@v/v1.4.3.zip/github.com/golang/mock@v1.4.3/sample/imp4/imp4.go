package imp_four

type Imp4 struct{}

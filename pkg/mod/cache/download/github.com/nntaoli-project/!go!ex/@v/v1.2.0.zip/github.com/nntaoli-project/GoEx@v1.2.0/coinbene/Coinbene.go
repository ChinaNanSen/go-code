package coinbene

type Coinbene struct {
	Swap *CoinbeneSwap
}

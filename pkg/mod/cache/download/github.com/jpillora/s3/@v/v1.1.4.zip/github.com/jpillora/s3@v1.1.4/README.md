[![Build Status](https://travis-ci.org/smartystreets/s3.svg?branch=master)](https://travis-ci.org/smartystreets/s3)
[![Code Coverage](https://codecov.io/gh/smartystreets/s3/branch/master/graph/badge.svg)](https://codecov.io/gh/smartystreets/s3)
[![Go Report Card](https://goreportcard.com/badge/github.com/smartystreets/s3)](https://goreportcard.com/report/github.com/smartystreets/s3)
[![GoDoc](https://godoc.org/github.com/smartystreets/s3?status.svg)](http://godoc.org/github.com/smartystreets/s3)

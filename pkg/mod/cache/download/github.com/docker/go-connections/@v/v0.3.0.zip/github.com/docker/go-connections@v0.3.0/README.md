[![GoDoc](https://godoc.org/github.com/docker/go-connections?status.svg)](https://godoc.org/github.com/docker/go-connections)

# Introduction

go-connections provides common package to work with network connections.

## Usage

See the [docs in godoc](https://godoc.org/github.com/docker/go-connections) for examples and documentation.

## License

go-connections is licensed under the Apache License, Version 2.0. See [LICENSE](LICENSE) for the full license text.

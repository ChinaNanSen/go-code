Release notes for this project are kept here: https://github.com/linode/linodego/releases

// Package condition provides strategies for waiting for infrastructure
// to reach a desired state through conditional predicates.
package condition

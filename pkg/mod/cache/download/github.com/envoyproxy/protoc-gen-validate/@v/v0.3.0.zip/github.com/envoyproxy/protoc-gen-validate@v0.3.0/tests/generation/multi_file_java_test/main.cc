#include <iostream>

#include "tests/generation/multi_file_java_test/test.pb.h"
#include "tests/generation/multi_file_java_test/test.pb.validate.h"

int main(int argc, char** argv) {
  return 0;
}

// +build !consulent

package prepared_query

var entMetaWalkFields = []string{}

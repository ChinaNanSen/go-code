package checks

const DefaultDockerHost = "npipe:////./pipe/docker_engine"

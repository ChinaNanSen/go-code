// +build !consulent

package config

type EnterpriseRuntimeConfig struct{}

// +build !go1.5

package goversion

func error() {
	`Bad go version, please install a version greater than or equal to 1.5`
}

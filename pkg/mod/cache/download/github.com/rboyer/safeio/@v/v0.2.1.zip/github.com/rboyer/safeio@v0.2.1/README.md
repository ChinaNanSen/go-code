Safe I/O
========

Provides functions to perform atomic, fsync-safe disk operations.

[![Build Status](https://travis-ci.org/rboyer/safeio.svg?branch=master)](https://travis-ci.org/rboyer/safeio)

# Release Notes

## 0.3.0

* Removed revocation claims in favor of timestamp-based revocation maps in account and export claims.

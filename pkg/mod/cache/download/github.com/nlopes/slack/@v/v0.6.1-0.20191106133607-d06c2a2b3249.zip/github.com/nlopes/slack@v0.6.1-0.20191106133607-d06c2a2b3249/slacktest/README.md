# slacktest

code in this package was shamelessly copied from https://github.com/lusis/slack-test.
since we were unable to get a response from the maintainer and its lack of license
have left us in an odd state. but wanted to move it here for maintenance purposes.

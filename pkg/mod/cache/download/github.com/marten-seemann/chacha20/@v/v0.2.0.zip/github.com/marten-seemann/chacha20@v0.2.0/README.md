# ChaCha20

Copy of https://godoc.org/golang.org/x/crypto/internal/chacha20, since this is an external package.
Also needs to copy to https://godoc.org/golang.org/x/crypto/internal/subtle.

package common

import (
	"testing"
)

func TestLoadEndpointFromFile(t *testing.T) {

}

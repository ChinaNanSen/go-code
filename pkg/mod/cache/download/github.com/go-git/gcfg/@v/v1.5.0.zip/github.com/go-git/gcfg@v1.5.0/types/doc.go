// Package types defines helpers for type conversions.
//
// The API for this package is not finalized yet.
package types

#!/bin/bash

/usr/sbin/kadmind &
/usr/sbin/krb5kdc -n
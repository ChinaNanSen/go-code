// Package gokrb5 provides a Kerberos 5 implementation for Go
package gokrb5

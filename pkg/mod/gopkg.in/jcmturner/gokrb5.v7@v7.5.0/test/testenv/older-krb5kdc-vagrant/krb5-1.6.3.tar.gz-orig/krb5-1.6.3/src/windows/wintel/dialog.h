#define IDM_SHOWCONSOLE 700

#define IDM_OPENTELNETDLG           200
#define TEL_CONNECT_NAME            201
#define TEL_USEDEFAULTS             202
#define TEL_MANUALCONFIGURE         203
#define TEL_OK                      204
#define TEL_CANCEL                  206
#define IDC_FORWARD                 207
#define IDC_FORWARDFORWARD          208
#define IDC_ENCRYPT                 210
#define TEL_CONNECT_USERID          211

#define IDM_SEND_IP                 800
#define IDM_SEND_AYT                801
#define IDM_SEND_ABORT              802

#define CON_SESSIONNAME             302
#define CON_WINDOWTITLE             304
#define CON_COLUMNS132              305
#define CON_COLUMNS80               306
#define CON_BACKSPACE               307
#define CON_DELETE                  308
#define CON_CRLF                    309
#define CON_CRNUL                   310
#define CON_BUFFERS                 311
#define CON_SENDS                   312
#define CON_OK                      320
#define CON_USEDEFAULTS             321
#define CONFIGDLG                   300
#define CON_SCRLBCK                 317
#define CON_NUMLINES                318

#define PRINTQUEUE                  400

#define IDM_PRINTQUEUE              500

#define TEL_PUSH1                   601
#define TEL_PUSH2                   602
#define TEL_PUSH3                   603
#define TEL_PUSH4                   604
#define TEL_PUSH5                   605
